# Telefonda APK oluşturma (GitHub Actions)

Bu proje henüz APK değildir. Bu iş akışı, GitHub hesabında projeyi derleyip APK'yı indirilebilir bir çıktı (artifact) olarak üretir.

1. GitHub'da yeni, boş bir repository oluştur.
2. Bu ZIP'i aç ve içindeki tüm dosyaları (gizli `.github` klasörü dahil) repository'ye yükle.
3. Repository'de **Actions** sekmesini aç.
4. **Build Alpendos AI APK** iş akışını seçip **Run workflow** düğmesine bas.
5. İşlem bitince tamamlanan çalışmanın sayfasında **Artifacts** bölümünden `AlpendosAI-debug-apk` dosyasını indir.
6. ZIP içindeki `app-debug.apk` dosyasını Poco F5 Pro'ya indirip kur.

Notlar:
- GitHub hesabı ve repository oluşturma/yükleme adımları kullanıcı tarafından yapılmalıdır; bu sohbet senin hesabına dosya yükleyemez.
- Bu ilk APK yalnızca yüzen paneli açıp kapatan prototiptir. Oyun ekranını analiz etmez ve oyuna otomatik dokunmaz.
