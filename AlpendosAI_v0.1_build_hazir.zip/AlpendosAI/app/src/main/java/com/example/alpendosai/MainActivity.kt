package com.example.alpendosai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "Alpendos AI v0.1\nEkran analiz yardımcısı"
            textSize = 23f
        })
        layout.addView(TextView(this).apply {
            text = "Bu ilk prototip yalnızca taşınabilir bir yardımcı pencere gösterir. Oyun içinde otomatik işlem yapmaz."
            textSize = 16f
            setPadding(0, 20, 0, 20)
        })
        layout.addView(Button(this).apply {
            text = "Yüzen pencere iznini ver"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "AI penceresini aç"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                } else {
                    (it as Button).text = "Önce yüzen pencere iznini ver"
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "AI penceresini kapat"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        setContentView(layout)
    }
}
