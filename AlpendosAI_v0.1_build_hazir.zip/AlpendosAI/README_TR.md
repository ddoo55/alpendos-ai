# Alpendos AI v0.1 — Android başlangıç projesi

Bu, Poco F5 Pro için hazırlanmış **kaynak kod prototipidir**, hazır APK değildir.

## Şu an ne yapıyor?
- Uygulama ana ekranı gösterir.
- Kullanıcıdan Android'in "diğer uygulamaların üzerinde göster" iznini ister.
- Alpendos AI adlı küçük bir yüzen pencere açar/kapatır.

## Henüz ne yapmıyor?
- Oyun ekranını okumaz veya ekran kaydı almaz.
- Otomatik savaş, sandık açma ya da oyun içi dokunma yapmaz.
- Yapay zekâ modeli içermez.

## Derleme
Projeyi Android Studio veya uyumlu bir Android IDE içinde açıp Gradle senkronizasyonu yaptıktan sonra `app` yapılandırmasını çalıştırın. Android SDK 35 ve JDK 17 gerekir.

## Telefonda izin
Uygulama açıldığında önce "Yüzen pencere iznini ver" düğmesine basın ve Android ayarlarında izni etkinleştirin. Sonra "AI penceresini aç" seçeneğini kullanın.

Bu prototip yalnızca arayüz başlangıcıdır. Sonraki aşamada kullanıcının açık izniyle ekran görüntüsü analizi (MediaProjection) eklenebilir. Çevrimiçi oyunda hile/otomatik oyun işlemleri yerine analiz ve geliştirici onaylı testler hedeflenmelidir.
